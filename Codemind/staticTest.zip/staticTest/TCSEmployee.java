package staticTest;

public class TCSEmployee {
	
	void println() {
		System.out.println("Inside TCSEmplyee println method");
	}

}
